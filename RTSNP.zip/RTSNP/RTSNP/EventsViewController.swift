//
//  EventsViewController.swift
//  RTSNP
//
//  Created by Kevin Olofson on 8/7/17.
//  Copyright © 2017 Kevin Olofson. All rights reserved.

import UIKit

class EventsViewController: UIViewController {
    
    @IBAction func EventsBack(_ sender: Any) {
        self.performSegue(withIdentifier: "BackFromEvents", sender: self)
    }
    
    @IBOutlet weak var EventsCalendar: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let EventsUrl = URL(string: "https://www.brownbearsw.com/cal/rollingthunder")
        
        EventsCalendar.loadRequest(URLRequest(url: EventsUrl!))
    }

    
    override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}


}
