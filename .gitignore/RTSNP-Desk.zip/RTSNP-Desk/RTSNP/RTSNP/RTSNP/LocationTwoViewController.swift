//
//  LocationTwoViewController.swift
//  RTSNP
//
//  Created by Kevin Olofson on 8/15/17.
//  Copyright © 2017 Kevin Olofson. All rights reserved.
//

import UIKit

class LocationTwoViewController: UIViewController  {
   
    @IBOutlet weak var WebpageNY: UIWebView!
    
    
    @IBAction func BackToLocations(_ sender: Any) {
        self.performSegue(withIdentifier: "NewYorkToLocations", sender: self)
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        let url = URL(string: "http://www.rtsnp.org")
        
        WebpageNY.loadRequest(URLRequest(url: url!))
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.

    }}
