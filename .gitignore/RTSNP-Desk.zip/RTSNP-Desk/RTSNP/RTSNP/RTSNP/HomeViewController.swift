//  HomeViewController.swift
//  RTSNP
//  Created by Kevin Olofson on 8/6/17.
//  Copyright © 2017 Kevin Olofson. All rights reserved.

import UIKit

class HomeViewController: UIViewController {
    
    
    
    
// buttons
    @IBAction func Events(_ sender: Any) {
        self.performSegue(withIdentifier: "EventsViewSegue", sender: self)
        
    }
    
    @IBAction func Website(_ sender: Any) {
        self.performSegue(withIdentifier: "WebsiteViewSegue", sender: self)
        
    }
    
    @IBAction func Facebook(_ sender: Any) {
        self.performSegue(withIdentifier: "FacebookSegue", sender: self)
    }
    
    
   @IBAction func AboutUs(_ sender: Any) {
        self.performSegue(withIdentifier: "AboutUsSegue", sender: self)
    }
    
    
    @IBAction func Locations(_ sender: Any) {
        self.performSegue(withIdentifier: "LocationsSegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

