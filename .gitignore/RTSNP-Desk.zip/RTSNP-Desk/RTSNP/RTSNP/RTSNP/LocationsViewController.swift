//
//  LocationsViewController.swift
//  RTSNP
//
//  Created by Kevin Olofson on 8/13/17.
//  Copyright © 2017 Kevin Olofson. All rights reserved.
//

import UIKit

class LocationsViewController: UIViewController {

    @IBAction func NewYork(_ sender: Any) {
        self.performSegue(withIdentifier: "LocationsToNewYork", sender: self)
    }
    
    @IBAction func Minnesota(_ sender: Any) {
        self.performSegue(withIdentifier: "ToLocationOne", sender: self)
    }
    @IBAction func LocationsToHome(_ sender: Any) {
        self.performSegue(withIdentifier: "LocationsToHome", sender: self)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.

}
}

