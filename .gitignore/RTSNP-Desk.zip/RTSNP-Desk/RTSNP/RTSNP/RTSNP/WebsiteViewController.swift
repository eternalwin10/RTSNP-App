//
//  WebsiteViewController.swift
//  RTSNP
//
//  Created by Kevin Olofson on 8/7/17.
//  Copyright © 2017 Kevin Olofson. All rights reserved.
//

import UIKit

class WebsiteViewController: UIViewController {
    
    @IBAction func WebsiteTohome(_ sender: Any) {
        self.performSegue(withIdentifier: "WebsiteToHome", sender: self)
    }
    @IBOutlet weak var WebView: UIWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = URL(string: "http://www.rtsnp.org")
        
        WebView.loadRequest(URLRequest(url: url!))
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
