//
//  FaceBookViewController.swift
//  RTSNP
//
//  Created by Kevin Olofson on 8/8/17.
//  Copyright © 2017 Kevin Olofson. All rights reserved.
//

import UIKit

class FacebookViewController: UIViewController {

    @IBAction func FacebookToHome(_ sender: Any) {
        self.performSegue(withIdentifier: "FacebookToHome", sender: self)
    }
    @IBOutlet weak var FacebookPageWebsite: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        let url = URL(string: "https://www.facebook.com/Rolling-Thunder-Special-Needs-Program-RTSNP-123816781047514/")
        
        FacebookPageWebsite.loadRequest(URLRequest(url: url!))
    }

    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
    
    
    }


    }

