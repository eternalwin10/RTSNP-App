//
//  LocationOneViewController.swift
//  RTSNP
//
//  Created by Kevin Olofson on 8/15/17.
//  Copyright © 2017 Kevin Olofson. All rights reserved.
//

import UIKit


class LocationOneViewController: UIViewController  {

    
    @IBAction func BackToLocations(_ sender: Any) {
        self.performSegue(withIdentifier: "LocationOneToLocations", sender: self)
    }
    
    @IBOutlet weak var Minnesota: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = URL(string: "http://www.rtsnp.org/minnesota.htm")
        
        Minnesota.loadRequest(URLRequest(url: url!))
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
// Dispose of any resources that can be recreated.

    }}
